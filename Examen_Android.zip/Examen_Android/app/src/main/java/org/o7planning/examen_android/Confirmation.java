package org.o7planning.examen_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Confirmation extends AppCompatActivity {

    private TextView Bienvenue = null;
    private Button Retour = null;
    private String nom;
    private String prenom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        // Récupération des éléments de l'interface
        Bienvenue = findViewById(R.id.Bienvenu);
        Retour = findViewById(R.id.Retour);


        // Récupération des données transmises depuis l'activité précédente
        Intent intent = getIntent();
        if (intent != null) {
            nom = intent.getStringExtra("EntreNom");
            prenom = intent.getStringExtra("EntrePrenom");
        }

        // Construction du message de bienvenue avec le nom et prénom
        String message = "Bienvenue, " + prenom + " " + nom + " !";
        Bienvenue.setText(message);


        // Définition du click et de la récupération pour le bouton de retour
        Retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Création d'un intent pour retourner à l'activité d'accueil
                Intent CinquiemeActivite = new Intent(Confirmation.this, Accueil.class);
                startActivity(CinquiemeActivite);
            }
        });
    }
}

package org.o7planning.examen_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Inscription extends AppCompatActivity {
    private Button Valider = null;
    private EditText EntreNom = null;
    private EditText EntrePrenom = null;
    private EditText EntrePseudo = null;
    private EditText EntrePassword = null;
    private DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        // Récupération des éléments de l'interface
        Valider = findViewById(R.id.ValiderInscription);
        EntreNom = findViewById(R.id.EntreNom);
        EntrePrenom = findViewById(R.id.EntrePrenom);
        EntrePseudo = findViewById(R.id.EntrePseudo);
        EntrePassword = findViewById(R.id.EntrePassword);

        // Initialisation du DatabaseHelper pour gérer la base de données
        databaseHelper = new DatabaseHelper(this);


        // Définition du click et de la récupération du bouton de validation
        Valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Récupération des valeurs saisies dans les champs
                String nom_str = EntreNom.getText().toString();
                String prenom_str = EntrePrenom.getText().toString();
                String pseudo_str = EntrePseudo.getText().toString();
                String password_str = EntrePassword.getText().toString();


                // Vérification que tous les champs soient remplis
                if (!nom_str.equals("") && !prenom_str.equals("") && !pseudo_str.equals("") && !password_str.equals("")) {
                    // Insertion des données dans la base de données
                    boolean inserted = databaseHelper.insertUtilisateur(nom_str, prenom_str, pseudo_str, password_str);

                    // Vérification si l'insertion a réussi
                    if (inserted) {
                        // Création d'un intent pour démarrer l'activité d'accueil
                        Intent secondeActivite = new Intent(Inscription.this, Accueil.class);
                        // Passage des données à l'activité suivante
                        secondeActivite.putExtra("nom", nom_str);
                        secondeActivite.putExtra("prenom", prenom_str);
                        secondeActivite.putExtra("pseudo", pseudo_str);
                        secondeActivite.putExtra("password", password_str);
                        startActivity(secondeActivite);
                    } else {
                        // Affichage d'un message d'erreur en cas de problème d'insertion
                        Toast.makeText(Inscription.this, "Une erreur s'est produite lors de l'inscription", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Affichage d'un message si tous les champs ne sont pas remplis
                    Toast.makeText(Inscription.this, "Veuillez remplir l'intégralité des champs avant de valider", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}

package org.o7planning.examen_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Connexion extends AppCompatActivity {
    private Button Valider = null;
    private EditText EntrePseudo = null;
    private EditText EntrePassword = null;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connexion);

        // Récupération des éléments de l'interface
        Valider = findViewById(R.id.ValiderCompte);
        EntrePseudo = findViewById(R.id.PseudoLog);
        EntrePassword = findViewById(R.id.PasswordLog);


        // Initialisation du DatabaseHelper pour gérer la base de données
        databaseHelper = new DatabaseHelper(this);


        // Définition du click et de la récupération pour le bouton de validation
        Valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Récupération des valeurs saisies dans les champs
                String pseudo_str = EntrePseudo.getText().toString();
                String password_str = EntrePassword.getText().toString();

                // Vérification que les champs ne soient pas vides
                if (!pseudo_str.equals("") && !password_str.equals("")) {
                    // Vérification des informations d'identification dans la base de données
                    boolean credentialsValid = databaseHelper.checkCredentials(pseudo_str, password_str);

                    // Vérification si les informations d'identification sont valides
                    if (credentialsValid) {
                        // Création d'un intent pour démarrer l'activité de confirmation
                        Intent secondeActivite = new Intent(Connexion.this, Confirmation.class);
                        // Passage des données à l'activité suivante
                        secondeActivite.putExtra("pseudo", pseudo_str);
                        secondeActivite.putExtra("password", password_str);
                        startActivity(secondeActivite);
                    } else {
                        // Affichage d'un message d'erreur en cas d'informations d'identification incorrectes
                        Toast.makeText(Connexion.this, "Pseudo ou mot de passe incorrect", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Affichage d'un message si tous les champs ne sont pas remplis
                    Toast.makeText(Connexion.this, "Veuillez remplir l'intégralité des champs avant de valider", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
package org.o7planning.examen_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Accueil extends AppCompatActivity {
    private Button Connexion = null;
    private Button Inscription = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accueil);

        // Récupération des boutons de l'interface
        Connexion = (Button) findViewById(R.id.connexion);
        Inscription = (Button) findViewById(R.id.inscription);


        // On définit le click et la récupération pour le bouton connexion
        Connexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Création de l'intent pour passer sur la page Connexion
                Intent PremiereActivite = new Intent(Accueil.this, Connexion.class);
                startActivity(PremiereActivite);
            }
        });


        // On définit le click et la récupération pour le bouton d'inscription
        Inscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Création de l'intent pour passer sur la page Inscription
                Intent SecondActivite = new Intent(Accueil.this, Inscription.class);
                startActivity(SecondActivite);
            }
        });
    }
}